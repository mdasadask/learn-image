<?php 
    include("inc/header.php")
?>

<?php 
    include("logo.php")
?>

<?php 
    include("inc/footer.php")
?>