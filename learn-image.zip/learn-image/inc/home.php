<!-- Services Start -->
<div class="container-fluid py-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-3">
                <h6 class="text-uppercase">Our Practice</h6>
                <h1 class="mb-4">Our Practice Areas</h1>
                <p>Invidunt lorem justo clita. Erat lorem labore ea, justo dolor lorem ipsum ut sed eos, ipsum et
                    dolor kasd sit ea justo. Erat justo sed sed diam. Ea et erat ut sed diam sea ipsum</p>
                <a href="" class="btn btn-primary mt-2">More Services</a>
            </div>
            <div class="col-lg-9 pt-5 pt-lg-0">
                <div class="bg-primary rounded" style="height: 200px;"></div>
                <div class="owl-carousel service-carousel position-relative"
                    style="margin-top: -100px; padding: 0 30px;">
                    <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                        <div class="icon-box bg-secondary text-primary mt-2 mb-4">
                            <i class="fa fa-2x fa-landmark"></i>
                        </div>
                        <h5 class="mb-4 px-4">Civil Law</h5>
                        <p class="m-0">Takim stet justo elitr sea eirmod vero ipsum. Sed Stet clita sit duo dolor
                            stet at at. Tempor dolor sit ipsum</p>
                    </div>
                    <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                        <div class="icon-box bg-secondary text-primary mt-2 mb-4">
                            <i class="fa fa-2x fa-users"></i>
                        </div>
                        <h5 class="mb-4 px-4">Family Law</h5>
                        <p class="m-0">Takim stet justo elitr sea eirmod vero ipsum. Sed Stet clita sit duo dolor
                            stet at at. Tempor dolor sit ipsum</p>
                    </div>
                    <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                        <div class="icon-box bg-secondary text-primary mt-2 mb-4">
                            <i class="fa fa-2x fa-hand-holding-usd"></i>
                        </div>
                        <h5 class="mb-4 px-4">Business Law</h5>
                        <p class="m-0">Takim stet justo elitr sea eirmod vero ipsum. Sed Stet clita sit duo dolor
                            stet at at. Tempor dolor sit ipsum</p>
                    </div>
                    <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                        <div class="icon-box bg-secondary text-primary mt-2 mb-4">
                            <i class="fa fa-2x fa-gavel"></i>
                        </div>
                        <h5 class="mb-4 px-4">Criminal Law</h5>
                        <p class="m-0">Takim stet justo elitr sea eirmod vero ipsum. Sed Stet clita sit duo dolor
                            stet at at. Tempor dolor sit ipsum</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Services End -->

<!-- Team Start -->
<div class="container-fluid py-5">
    <div class="container py-5">
        <div class="text-center pb-2">
            <h6 class="text-uppercase">Our Attorneys</h6>
            <h1 class="mb-4">Meet Our Attorneys</h1>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="bg-primary rounded" style="height: 200px;"></div>
                <div class="owl-carousel team-carousel position-relative" style="margin-top: -97px; padding: 0 30px;">
                    <div class="team-item text-center bg-white rounded overflow-hidden pt-4">
                        <h5 class="mb-2 px-4">Attorney Name</h5>
                        <p class="mb-3 px-4">Practice Area</p>
                        <div class="team-img position-relative">
                            <img class="img-fluid" src="css-js/img/team-1.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-item text-center bg-white rounded overflow-hidden pt-4">
                        <h5 class="mb-2 px-4">Attorney Name</h5>
                        <p class="mb-3 px-4">Practice Area</p>
                        <div class="team-img position-relative">
                            <img class="img-fluid" src="css-js/img/team-2.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-item text-center bg-white rounded overflow-hidden pt-4">
                        <h5 class="mb-2 px-4">Attorney Name</h5>
                        <p class="mb-3 px-4">Practice Area</p>
                        <div class="team-img position-relative">
                            <img class="img-fluid" src="css-js/img/team-3.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-item text-center bg-white rounded overflow-hidden pt-4">
                        <h5 class="mb-2 px-4">Attorney Name</h5>
                        <p class="mb-3 px-4">Practice Area</p>
                        <div class="team-img position-relative">
                            <img class="img-fluid" src="css-js/img/team-4.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-item text-center bg-white rounded overflow-hidden pt-4">
                        <h5 class="mb-2 px-4">Attorney Name</h5>
                        <p class="mb-3 px-4">Practice Area</p>
                        <div class="team-img position-relative">
                            <img class="img-fluid" src="css-js/img/team-5.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-light btn-square mx-1" href="#"><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Team End -->