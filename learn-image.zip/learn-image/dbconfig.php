<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "learn-image";
$con = new mysqli($servername, $username, $password, $db);
?>