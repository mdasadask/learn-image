<?php
include("dbconfig.php");
session_start();
if($_SESSION['login'] == true){
    header('location: admin/index.php');
}

if ($con->connect_error) {
    die("Connection failed...: " . $con->connect_error);
}else{
    if(isset($_POST["submit"])) {
        $email = $_POST["uemail"];
        $password = $_POST["password"];
        $query = mysqli_query($con, "SELECT `password` FROM `admins` WHERE email='$email'");
        $db_pass = mysqli_fetch_assoc($query);
        $db_password = $db_pass['password'];
        if ($password == $db_password) {
            session_start();
            $_SESSION['login'] = true;
            header('location: admin/index.php');
        }else{
            echo '<p style="color: red;"><br> Invalid Credentials <br></p>';
        }
      }
}

?>

<?php 
    include("inc/header.php");
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asad</title>
</head>

<body>
    <div class="container">
        <form action="" method="POST">
            <br>
            <h2>LOGIN</h2>

            <label>User Email: </label>

            <input type="text" name="uemail" placeholder="User email"><br>

            <label>Password: </label>

            <input type="password" name="password" placeholder="Password"><br>

            <button type="submit" name="submit">Login</button>

        </form>
    </div>

</body>

</html>


<?php 
    include("inc/footer.php");
?>