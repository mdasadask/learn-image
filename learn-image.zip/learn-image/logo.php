<?php
    include("dbconfig.php");
    date_default_timezone_set("Asia/Dhaka");
    $query = mysqli_query($con, "SELECT `name` FROM `static_images` ORDER BY id DESC LIMIT 1");
    $image_name = mysqli_fetch_assoc($query);
    $img_name = $image_name['name'];

    $query_t = mysqli_query($con, "SELECT * FROM `temporary_images` ORDER BY id DESC LIMIT 1");
    $image_name2 = mysqli_fetch_assoc($query_t);
    $img_name2 = $image_name2['name'];
    $time2 = $image_name2['time'];

    $created_time = strtotime($image_name2['created_at']);
    $now_time = time();
    $end_time = $created_time + $time2 * 60;
    $diff_time = $now_time - $created_time;
    $a = $time2 * 60;

    echo "<br>";
    //echo "created_time = ".$created_time."<br>";
    //echo "end_time = ".$end_time."<br>";
    //echo "now_time = ".$now_time."<br>";
    echo "Diff(now_time - created_time): <br>";
    echo "<span id=\"showDemo\">Countdown = ".$diff_time."</span><br>";
    echo "Temporary image set for = ".$a." Seconds <br>";

    
?>


<!-- Services Start -->
<div class="container-fluid py-5">
    <div class="container py-5">

        <h3>Static Logo</h3> <br>
        <img src="all-image/<?php echo $img_name; ?>" alt="B Image"
            style="border-radius: 50px; border: 5px solid #555; height: 100px; width: 100px;">

        <br> <br> <br>

        <h3>Temporary Logo (MetLife)</h3> <br>
        <?php if ($end_time > $now_time) { ?>
        <img id="changeableImage" src="all-image/<?php echo $img_name2; ?>" alt="D Image"
            style="border-radius: 50px; border: 5px solid #555; height: 100px; width: 100px;">
        <br> <br> <br>
        <?php   } else{ ?>
        <img src="all-image/d.jpg" alt="D Image"
            style="border-radius: 50px; border: 5px solid #555; height: 100px; width: 100px;">
        <br> <br> <br>
        <?php   }  ?>

    </div>
</div>
<!-- Services End -->

<script>
$(document).ready(function() {
    //alert("okok");
    var end_time = "<?php echo $end_time; ?>";
    created_time
    var now_time = "<?php echo $now_time; ?>";
    var created_time = "<?php echo $created_time; ?>";
    var img_name2 = "<?php echo $img_name2; ?>";
    if (end_time > now_time) {
        setInterval(checkData, 1000);
    }


    var increment = 1;

    function checkData() {
        //alert(now_time + "__" + end_time + "__" + increment);
        var diff_time = 0;
        if (parseInt(end_time) < parseInt(now_time)) {
            location.reload();
            now_time = 0;
            increment = 0;
        } else {
            now_time = parseInt(now_time) + increment;
            diff_time = now_time - created_time;
            document.getElementById("showDemo").innerHTML = "Countdown = " + diff_time;
        }
    }
});
</script>