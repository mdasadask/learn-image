<br>

<?php
include("../dbconfig.php");

if(isset($_POST["submit"])) {
    $path = $_FILES['up_img']['name'];
    $ext = pathinfo($path, PATHINFO_EXTENSION); 
    $name = 'static_'.date('d-m-Y_his.').$ext;
    $size = $_FILES['up_img']['size'];
    if ($ext == 'PNG' || $ext == 'png' || $ext == 'JPG' || $ext == 'jpg' || $ext == 'JPEG' || $ext == 'jpeg') {
        if ($size < 1048576 ) {
            move_uploaded_file($_FILES['up_img']['tmp_name'], "../all-image/".$name);
            $query = mysqli_query($con, "INSERT INTO static_images (name) VALUES ('$name')");
            echo '<p style="color: green;"><br> Image uploaded successfully... <br></p>';
        }else{
            echo '<p style="color: red;"><br> Please select less than 1 MB image. <br></p>';
        }
    } else {
        echo '<p style="color: red;"><br> Please select jpg, png, jpeg file <br></p>';
    }
    
}

?>

<!DOCTYPE html>
<html>

<body>
    <br> <br>

    <form action="" method="POST" enctype="multipart/form-data">
        Select image to upload:
        <input type="file" name="up_img" id="up_img">
        <input type="submit" value="Upload Image" name="submit">
    </form>

</body>

</html>