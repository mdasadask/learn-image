<?php 
session_start();
if($_SESSION['login'] == false){
  $login = '../login.php';
  header('Location: '.$login);
}
?>

<?php 
    include("inc-admin/header-ad.php")
?>

<?php 
    include("inc-admin/inc-static.php")
?>

<?php 
    include("inc-admin/footer-ad.php")
?>