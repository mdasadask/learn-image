<div class="row">
    <col-md-3>
        <h3>Admin Home</h3> <br>
        <img src="../all-image/b.jpg" alt="B Image"
            style="border-radius: 50px; border: 5px solid #555; height: 80px; width: 80px;">
    </col-md-3>
</div>