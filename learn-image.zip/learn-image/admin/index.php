<?php 
session_start();
if($_SESSION['login'] == false){
  $login = '../login.php';
  header('Location: '.$login);
}
?>

<?php 
    include("inc-admin/header-ad.php")
?>

<?php 
    include("home.php")
?>

<?php 
    include("inc-admin/footer-ad.php")
?>