<?php 
session_start();
if($_SESSION['login'] == true){
  $_SESSION['login'] = false;
  $login = '../login.php';
  header('Location: '.$login);
}
?>